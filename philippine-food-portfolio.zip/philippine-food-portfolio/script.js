function showMessage(){
alert("Filipino food is known for its rich flavors and cultural influences!");
}